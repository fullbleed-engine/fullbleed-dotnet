using FullBleed.DotNet;
using System.Diagnostics;
using System.Security.Cryptography;
using System.Text.Json;

if (args.Length != 4) throw new ArgumentException("inputs, font, output and expected binding version are required");
var output = Path.GetFullPath(args[2]);
if (Directory.Exists(output)) throw new InvalidOperationException("Preserve existing output");
Directory.CreateDirectory(output);
var inputBytes = File.ReadAllBytes(args[0]);
using var inputs = JsonDocument.Parse(inputBytes);
var features = FullBleedEngine.GetNativeFeatures();
if (features.BindingVersion != args[3] || features.AbiVersion != 1) throw new InvalidOperationException("Unexpected native binding");
var fontHash = Hash(File.ReadAllBytes(args[1]));
if (fontHash != inputs.RootElement.GetProperty("fontSha256").GetString()) throw new InvalidOperationException("Unexpected font");
using var engine = new FullBleedEngine(new FullBleedEngineOptions
{
    Assets = [FullBleedAsset.FromPath(Path.GetFullPath(args[1]), FullBleedAssetKind.Font)]
});
File.WriteAllBytes(Path.Combine(output, "inputs.json"), inputBytes);
var rows = new List<object>();
foreach (var fixture in inputs.RootElement.GetProperty("cases").EnumerateArray())
{
    var name = fixture.GetProperty("name").GetString()!;
    var html = fixture.GetProperty("html").GetString()!;
    var css = fixture.GetProperty("css").GetString()!;
    var folder = Path.Combine(output, name);
    Directory.CreateDirectory(folder);
    File.WriteAllText(Path.Combine(folder, "input.html"), html);
    File.WriteAllText(Path.Combine(folder, "style.css"), css);
    var result = engine.RenderPdfWithDiagnostics(html, css);
    if (result.Diagnostics.MissingGlyphs.Count != 0) throw new InvalidOperationException("Missing glyphs: " + name);
    if (!result.Pdf.SequenceEqual(engine.RenderPdf(html, css))) throw new InvalidOperationException("Nondeterministic PDF: " + name);
    var pdfPath = Path.Combine(folder, "document.pdf");
    File.WriteAllBytes(pdfPath, result.Pdf);
    if (FullBleedEngine.InspectPdf(pdfPath).PageCount != 1) throw new InvalidOperationException("Unexpected pages: " + name);
    File.WriteAllBytes(Path.Combine(folder, "undecorated.pdf"), engine.RenderPdf(html, css + ".dec {text-decoration:none}"));
    var direct = engine.RenderImagePagesToDirectory(html, css, folder, dpi: 144, stem: "direct");
    var finalized = engine.RenderFinalizedPdfImagePagesToDirectory(pdfPath, folder, dpi: 144, stem: "finalized");
    if (direct.Paths.Count != 1 || finalized.Paths.Count != 1) throw new InvalidOperationException("Unexpected previews: " + name);
    File.Copy(direct.Paths[0], Path.Combine(folder, "native.png"));
    File.Copy(finalized.Paths[0], Path.Combine(folder, "finalized.png"));
    rows.Add(new { name, pdfSha256 = Hash(result.Pdf), nativeSha256 = Hash(File.ReadAllBytes(direct.Paths[0])),
        finalizedSha256 = Hash(File.ReadAllBytes(finalized.Paths[0])), deterministic = true, missingGlyphs = 0 });
}
if (rows.Count != 16) throw new InvalidOperationException("Unexpected fixture count");
var module = Process.GetCurrentProcess().Modules.Cast<ProcessModule>().Single(item =>
    Path.GetFileName(item.FileName).Equals("fullbleed_dotnet_native.dll", StringComparison.OrdinalIgnoreCase));
var record = new { packageVersion = features.BindingVersion, nativeAbi = features.AbiVersion,
    runtime = System.Runtime.InteropServices.RuntimeInformation.FrameworkDescription,
    nativePath = module.FileName, nativeSha256 = Hash(File.ReadAllBytes(module.FileName)),
    sourceSha256 = Hash(inputBytes), fontSha256 = fontHash, cases = rows };
File.WriteAllText(Path.Combine(output, "renders.json"), JsonSerializer.Serialize(record, new JsonSerializerOptions { WriteIndented = true }) + "\n");
Console.WriteLine(JsonSerializer.Serialize(new { packageVersion = features.BindingVersion, cases = rows.Count, nativeAbi = features.AbiVersion }));

static string Hash(byte[] bytes) => Convert.ToHexString(SHA256.HashData(bytes)).ToLowerInvariant();
